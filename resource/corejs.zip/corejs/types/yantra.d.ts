/**
 * yantra (TypeScript) — corrected for FormData typing + no duplicate global declarations
 * Consolidated library: helpers + engine + adapter + basic plugin
 *
 * Adjustments:
 * - FormData iteration uses (fd as any).keys() / getAll()
 * - Indexing uses (data as any)[k]
 * - Removed duplicate `declare global` block to avoid TS2687 in certain projects
 *
 * Build with: esbuild + tsc --emitDeclarationOnly
 */
export interface UploadResult {
    fileId: string;
}
export interface FetchResult {
    [k: string]: any;
}
export interface YantraAPI {
    toast(message: string, opts?: {
        duration?: number;
        group?: string;
    }): HTMLElement | void;
    showLoader(): void;
    hideLoader(): void;
    fetchJson(url: string, opts?: RequestInit & {
        timeout?: number;
    }): Promise<any>;
    postJson(url: string, data: any, opts?: {
        timeout?: number;
    }): Promise<any>;
    buildFormData(obj: any, form?: FormData, namespace?: string): FormData;
    loadScript(src: string, opts?: {
        async?: boolean;
        module?: boolean;
    }): Promise<HTMLScriptElement>;
    store: {
        set(k: string, v: any): void;
        get<T = any>(k: string, def?: T): T | null;
        remove(k: string): void;
        clear(): void;
    };
    download(blobOrUrl: Blob | string, filename?: string): void;
    copyToClipboard(text: string): Promise<void>;
    createForm?: (selectorOrEl: string | HTMLFormElement, opts?: Partial<YantraFormOptions>) => YantraForm | null;
    uploadFileInChunks?: (file: File, opts?: {
        url?: string;
        onProgress?: (pct: number) => void;
        registerFieldId?: string;
    }) => Promise<UploadResult>;
}
export interface YantraFormOptions {
    url?: string;
    method?: 'POST' | 'GET' | 'PUT' | 'DELETE' | 'PATCH';
    ajax?: boolean;
    validateOn?: 'submit' | 'input' | 'blur';
    queue?: boolean;
    autoReset?: boolean;
    formDataMode?: 'formdata' | 'json';
    fetchRetries?: number;
    fetchTimeout?: number;
    autoSaveKey?: string | null;
    extraFields?: Record<string, any>;
    headers?: Record<string, string>;
    serverErrorMapper?: (raw: any) => {
        fieldErrors?: Record<string, string>;
        globalErrors?: string[];
    } | null;
    debug?: boolean;
    [k: string]: any;
}
export type ValidatorFn = (value: any, param?: string | null, field?: Element | null) => true | string;
declare class Emitter {
    private _map;
    constructor();
    on(event: string, fn: (...args: any[]) => any): this;
    off(event: string, fn?: (...args: any[]) => any): this;
    emit(event: string, ...args: any[]): any[];
}
declare class ValidatorRegistry {
    private _map;
    constructor();
    register(name: string, fn: ValidatorFn): this;
    has(name: string): boolean;
    run(name: string, value: any, param?: string | null, field?: Element | null): string | true;
}
export declare class YantraForm {
    form: HTMLFormElement;
    opts: YantraFormOptions;
    emitter: Emitter;
    validators: ValidatorRegistry;
    plugins: any[];
    private _boundSubmit;
    private _autosaveHandler;
    private _conditionalHandler;
    private _destroyed;
    debug: boolean;
    localQueue: Promise<any>;
    serverGlobalErrors: string[];
    constructor(selectorOrEl: string | HTMLFormElement, options?: Partial<YantraFormOptions>);
    registerValidator(name: string, fn: ValidatorFn): this;
    use(pluginFactoryOrPlugin: any): this;
    on(event: string, cb: (...args: any[]) => any): this;
    off(event: string, cb?: (...args: any[]) => any): this;
    getData(): Record<string, any>;
    private _attachAutoValidation;
    private _onDomSubmit;
    private _validateAll;
    private _renderFieldError;
    private _clearFieldError;
    submit(): Promise<any>;
    applyServerErrors(mapped: {
        fieldErrors?: Record<string, string>;
        globalErrors?: string[];
    } | null, raw?: any): boolean;
    private _initRepeatables;
    private _applyConditionalFields;
    enableAutoSave(key: string, opts?: {
        interval?: number;
        restore?: boolean;
    }): this;
    private _autoSaveIntervalId;
    private _saveDraft;
    clearDraft(): void;
    destroy(): void;
}
export declare const Plugins: {
    chunkUploader: (options?: any) => (engine: YantraForm) => {
        beforeSubmit: (frmEngine: YantraForm) => Promise<{
            continue: boolean;
            uploads?: undefined;
        } | {
            continue: boolean;
            uploads: (UploadResult | null)[];
        }>;
    };
};
declare const _default: YantraAPI;
export default _default;
