// src/types/global.d.ts
import { YantraAPI, YantraForm } from '../yantra';

declare global {
  interface Window {
    yantra: YantraAPI;
    YantraForm: typeof YantraForm;
  }
}
