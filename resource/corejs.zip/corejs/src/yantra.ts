// src/yantra.ts
/**
 * yantra (TypeScript) — corrected for FormData typing + no duplicate global declarations
 * Consolidated library: helpers + engine + adapter + basic plugin
 *
 * Adjustments:
 * - FormData iteration uses (fd as any).keys() / getAll()
 * - Indexing uses (data as any)[k]
 * - Removed duplicate `declare global` block to avoid TS2687 in certain projects
 *
 * Build with: esbuild + tsc --emitDeclarationOnly
 */

type AnyObject = { [k: string]: any };

/* ----------------------
   Public type exports
   ---------------------- */
export interface UploadResult { fileId: string }
export interface FetchResult { [k: string]: any }

export interface YantraAPI {
  toast(message: string, opts?: { duration?: number, group?: string }): HTMLElement | void;
  showLoader(): void;
  hideLoader(): void;
  fetchJson(url: string, opts?: RequestInit & { timeout?: number }): Promise<any>;
  postJson(url: string, data: any, opts?: { timeout?: number }): Promise<any>;
  buildFormData(obj: any, form?: FormData, namespace?: string): FormData;
  loadScript(src: string, opts?: { async?: boolean, module?: boolean }): Promise<HTMLScriptElement>;
  store: {
    set(k: string, v: any): void;
    get<T = any>(k: string, def?: T): T | null;
    remove(k: string): void;
    clear(): void;
  };
  download(blobOrUrl: Blob | string, filename?: string): void;
  copyToClipboard(text: string): Promise<void>;
  createForm?: (selectorOrEl: string | HTMLFormElement, opts?: Partial<YantraFormOptions>) => YantraForm | null;
  uploadFileInChunks?: (file: File, opts?: { url?: string, onProgress?: (pct: number) => void, registerFieldId?: string }) => Promise<UploadResult>;
}

export interface YantraFormOptions {
  url?: string;
  method?: 'POST' | 'GET' | 'PUT' | 'DELETE' | 'PATCH';
  ajax?: boolean;
  validateOn?: 'submit' | 'input' | 'blur';
  queue?: boolean;
  autoReset?: boolean;
  formDataMode?: 'formdata' | 'json';
  fetchRetries?: number;
  fetchTimeout?: number;
  autoSaveKey?: string | null;
  extraFields?: Record<string, any>;
  headers?: Record<string, string>;
  serverErrorMapper?: (raw: any) => { fieldErrors?: Record<string, string>, globalErrors?: string[] } | null;
  debug?: boolean;
  [k: string]: any;
}

export type ValidatorFn = (value: any, param?: string | null, field?: Element | null) => true | string;

/* ----------------------
   Utilities
   ---------------------- */

function noop(): void { /* no-op */ }

function assign<T, U>(dst: T, src: U): T & U {
  return Object.assign(dst as any, src as any);
}

function debounce<T extends (...args: any[]) => any>(fn: T, wait = 200): T {
  let timer: number | null = null;
  let lastArgs: any;
  return ((...args: any[]) => {
    lastArgs = args;
    if (timer) window.clearTimeout(timer);
    timer = window.setTimeout(() => { timer = null; fn(...lastArgs); }, wait);
  }) as T;
}

function throttleByTime<T extends (...args: any[]) => any>(fn: T, ms: number): T {
  let last = 0;
  let scheduled: number | null = null;
  let lastArgs: any;
  return ((...args: any[]) => {
    const now = Date.now();
    lastArgs = args;
    if (now - last >= ms) {
      last = now;
      fn(...args);
    } else {
      if (scheduled) return;
      scheduled = window.setTimeout(() => {
        scheduled = null;
        last = Date.now();
        fn(...lastArgs);
      }, ms - (now - last));
    }
  }) as T;
}

/* ----------------------
   Fast Emitter
   ---------------------- */
class Emitter {
  private _map: Record<string, Array<(...args: any[]) => any>>;
  constructor() { this._map = Object.create(null); }
  on(event: string, fn: (...args: any[]) => any) {
    (this._map[event] || (this._map[event] = [])).push(fn);
    return this;
  }
  off(event: string, fn?: (...args: any[]) => any) {
    const a = this._map[event];
    if (!a) return this;
    if (!fn) { delete this._map[event]; return this; }
    for (let i = a.length - 1; i >= 0; --i) if (a[i] === fn) a.splice(i, 1);
    return this;
  }
  emit(event: string, ...args: any[]) {
    const a = this._map[event];
    if (!a || a.length === 0) return [];
    const results: any[] = [];
    for (let i = 0; i < a.length; ++i) {
      try { results.push(a[i](...args)); } catch (err) { console.error('yantra emitter error', err); results.push(undefined); }
    }
    return results;
  }
}

/* ----------------------
   fetchWithRetries
   ---------------------- */
async function fetchWithRetries(url: string, opts: RequestInit = {}, retries = 1, timeout = 7000): Promise<any> {
  const baseOpts: any = Object.assign({}, opts);
  let lastErr: any = null;
  for (let attempt = 0; attempt <= retries; ++attempt) {
    let controller: AbortController | null = null;
    let timer: number | null = null;
    try {
      if (typeof AbortController !== 'undefined' && timeout > 0) {
        controller = new AbortController();
        baseOpts.signal = controller.signal;
        timer = window.setTimeout(() => controller && controller.abort(), timeout);
      }
      const res = await fetch(url, baseOpts);
      if (timer) window.clearTimeout(timer);
      if (!res.ok) {
        const txt = await res.text().catch(() => null);
        const err = new Error('HTTP ' + res.status);
        (err as any).status = res.status;
        (err as any).body = txt;
        throw err;
      }
      const ct = (res.headers.get('content-type') || '').toLowerCase();
      if (ct.indexOf('application/json') !== -1) return await res.json().catch(() => null);
      return await res.text().catch(() => null);
    } catch (err) {
      lastErr = (err && (err as any).name === 'AbortError') ? new Error('Request timeout') : err;
      if (attempt >= retries) throw lastErr;
      await new Promise(r => setTimeout(r, 120 * (attempt + 1)));
    } finally {
      if (timer) window.clearTimeout(timer);
      if (baseOpts.signal) delete baseOpts.signal;
    }
  }
  throw lastErr;
}

/* ----------------------
   yantra helpers implementation
   ---------------------- */
const yantra: Partial<YantraAPI> = {};

// Toast containers cached by group
const _toastContainers = new Map<string, HTMLElement>();
function _ensureToastContainer(group: string) {
  if (_toastContainers.has(group)) return _toastContainers.get(group)!;
  const container = document.createElement('div');
  container.className = 'yantra-toast-container';
  container.dataset.group = group;
  Object.assign(container.style, {
    position: 'fixed', right: '16px', bottom: '16px', zIndex: 99999,
    display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '8px'
  } as any);
  document.body.appendChild(container);
  _toastContainers.set(group, container);
  return container;
}

yantra.toast = function (message: string, opts?: { duration?: number, group?: string }) {
  opts = opts || {};
  const duration = typeof opts.duration === 'number' ? opts.duration : 3500;
  const group = opts.group || 'default';
  const container = _ensureToastContainer(group);
  const el = document.createElement('div');
  el.className = 'yantra-toast';
  Object.assign(el.style, {
    background: 'rgba(0,0,0,0.85)', color: '#fff',
    padding: '8px 12px', borderRadius: '6px', boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
    maxWidth: '320px'
  } as any);
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity .25s ease, transform .25s ease';
    el.style.opacity = '0';
    el.style.transform = 'translateY(8px)';
    setTimeout(() => el.remove(), 260);
  }, duration);
  return el;
};

yantra.showLoader = function () {
  if (document.getElementById('page-loader')) return;
  const loader = document.createElement('div');
  loader.id = 'page-loader';
  loader.setAttribute('aria-hidden', 'true');
  loader.innerHTML = '<div class="yantra-loader-spinner" style="width:48px;height:48px;border:6px solid rgba(0,0,0,0.1);border-top-color:#1976d2;border-radius:50%;animation:yantra-spin 1s linear infinite;margin:20px auto"></div>';
  Object.assign(loader.style, { position: 'fixed', left: '0', top: '0', right: '0', bottom: '0', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(255,255,255,0.6)', zIndex: 100000 } as any);
  document.body.appendChild(loader);
  if (!document.getElementById('yantra-loader-style')) {
    const s = document.createElement('style'); s.id = 'yantra-loader-style';
    s.innerHTML = '@keyframes yantra-spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}';
    document.head.appendChild(s);
  }
};

yantra.hideLoader = function () {
  const el = document.getElementById('page-loader'); if (el) el.remove();
  const s = document.getElementById('yantra-loader-style'); if (s) s.remove();
};

yantra.fetchJson = async function (url: string, opts?: RequestInit & { timeout?: number }) {
  opts = opts || {};
  const method = opts.method || 'GET';
  const headers = opts.headers || {};
  const body = opts.body || null;
  const timeout = (opts as any).timeout || 0;
  let controller: AbortController | null = null;
  let timer: number | null = null;
  if (timeout) {
    controller = new AbortController();
    timer = window.setTimeout(() => controller && controller.abort(), timeout);
  }
  const r = await fetch(url, Object.assign({ method, headers, body, signal: controller ? controller.signal : undefined }, opts));
  if (timer) window.clearTimeout(timer);
  const text = await r.text().catch(() => null);
  if (!r.ok) { const err = new Error('HTTP ' + r.status); (err as any).status = r.status; (err as any).body = text; throw err; }
  try { return JSON.parse(text as any); } catch (e) { return text; }
};

yantra.postJson = function (url: string, data: any, opts?: { timeout?: number }) {
  opts = opts || {};
  const headers = Object.assign({}, (opts as any).headers || {}, { 'Content-Type': 'application/json' });
  return yantra.fetchJson!(url, { method: 'POST', headers, body: JSON.stringify(data), timeout: (opts && opts.timeout) || 0 } as any);
};

yantra.buildFormData = function buildFormData(obj: any, form?: FormData, namespace?: string): FormData {
  const fd = form || new FormData();
  namespace = namespace || '';
  for (const prop in obj) {
    if (!Object.prototype.hasOwnProperty.call(obj, prop)) continue;
    const key = namespace ? (namespace + '[' + prop + ']') : prop;
    const val = obj[prop];
    if (val instanceof Date) fd.append(key, val.toISOString());
    else if (val instanceof File || val instanceof Blob) fd.append(key, val);
    else if (Array.isArray(val)) {
      for (let i = 0; i < val.length; ++i) {
        const v = val[i];
        const k = key + '[' + i + ']';
        if (v !== null && typeof v === 'object') buildFormData(v, fd, k); else fd.append(k, v);
      }
    } else if (val !== null && typeof val === 'object') buildFormData(val, fd, key);
    else if (val !== undefined) fd.append(key, val == null ? '' : String(val));
  }
  return fd;
};

yantra.loadScript = function (src: string, opts?: { async?: boolean, module?: boolean }) {
  opts = opts || {};
  return new Promise<HTMLScriptElement>((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    if (opts.async !== undefined) s.async = !!opts.async;
    if (opts.module) s.type = 'module';
    s.onload = () => resolve(s);
    s.onerror = (e) => reject(e);
    document.head.appendChild(s);
  });
};

yantra.store = {
  set(k: string, v: any) {
    try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
  },
  get<T = any>(k: string, def?: T) {
    const defaultVal = (def === undefined) ? null : def;
    try { const v = localStorage.getItem(k); return v ? JSON.parse(v) as T : defaultVal as T | null; } catch (e) { try { const v = sessionStorage.getItem(k); return v ? JSON.parse(v) as T : defaultVal as T | null; } catch (e) { return defaultVal as T | null; } }
  },
  remove(k: string) { try { localStorage.removeItem(k); } catch (e) { try { sessionStorage.removeItem(k); } catch (e) { } } },
  clear() { try { localStorage.clear(); } catch (e) { try { sessionStorage.clear(); } catch (e) { } } }
};

yantra.download = function (blobOrUrl: Blob | string, filename?: string) {
  filename = filename || 'download';
  if (typeof blobOrUrl === 'string') {
    const a = document.createElement('a'); a.href = blobOrUrl; a.download = filename; a.target = '_blank'; document.body.appendChild(a); a.click(); a.remove(); return;
  }
  const url = URL.createObjectURL(blobOrUrl);
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
};

yantra.copyToClipboard = function (text: string) {
  if (!navigator.clipboard) {
    const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (e) { throw e; } finally { ta.remove(); }
    return Promise.resolve();
  }
  return navigator.clipboard.writeText(text);
};

/* ----------------------
   Validator registry
   ---------------------- */
class ValidatorRegistry {
  private _map: Record<string, ValidatorFn>;
  constructor() { this._map = Object.create(null); }
  register(name: string, fn: ValidatorFn) {
    if (!name || typeof fn !== 'function') throw new Error('register(name, fn) expects a function');
    this._map[name] = fn;
    return this;
  }
  has(name: string) { return !!this._map[name]; }
  run(name: string, value: any, param?: string | null, field?: Element | null) {
    const fn = this._map[name];
    if (!fn) return true;
    try { return fn(value, param || null, field || null); } catch (e) { console.error('validator error', e); return 'Validation failed'; }
  }
}

/* ----------------------
   YantraForm engine
   ---------------------- */

const DEFAULTS: YantraFormOptions = {
  ajax: true, url: undefined, method: 'POST', validateOn: 'submit',
  queue: false, autoReset: false, formDataMode: 'formdata',
  fetchRetries: 2, fetchTimeout: 7000, debug: false
};

function isFunction(v: any): v is Function { return typeof v === 'function'; }

export class YantraForm {
  form: HTMLFormElement;
  opts: YantraFormOptions;
  emitter: Emitter;
  validators: ValidatorRegistry;
  plugins: any[] = [];
  private _boundSubmit: (e: Event) => void;
  private _autosaveHandler: any;
  private _conditionalHandler: any;
  private _destroyed = false;
  debug = false;
  localQueue: Promise<any> = Promise.resolve();
  serverGlobalErrors: string[] = [];

  constructor(selectorOrEl: string | HTMLFormElement, options: Partial<YantraFormOptions> = {}) {
    this.form = (typeof selectorOrEl === 'string') ? (document.querySelector(selectorOrEl) as HTMLFormElement) : selectorOrEl;
    if (!this.form || this.form.tagName !== 'FORM') throw new Error('YantraForm requires a form element or selector');
    this.opts = Object.assign({}, DEFAULTS, options) as YantraFormOptions;
    this.emitter = new Emitter();
    this.validators = new ValidatorRegistry();
    this._boundSubmit = (e: Event) => this._onDomSubmit(e);
    this.debug = !!this.opts.debug;
    this.form.addEventListener('submit', this._boundSubmit);
    // attach autosave/conditional handlers
    this._attachAutoValidation();
    try { (this.form as any).__yantra_form__ = this; } catch (e) { }
    this._applyConditionalFields();
    this._initRepeatables();
  }

  registerValidator(name: string, fn: ValidatorFn) { this.validators.register(name, fn); return this; }
  use(pluginFactoryOrPlugin: any) {
    if (typeof pluginFactoryOrPlugin === 'function') {
      const p = pluginFactoryOrPlugin(this);
      this.plugins.push(p || {});
      return this;
    }
    // if plugin object directly
    this.plugins.push(pluginFactoryOrPlugin);
    return this;
  }
  on(event: string, cb: (...args: any[]) => any) { this.emitter.on(event, cb); return this; }
  off(event: string, cb?: (...args: any[]) => any) { this.emitter.off(event, cb); return this; }

  getData(): Record<string, any> {
    const data: Record<string, any> = Object.create(null);
    const fd = new FormData(this.form);

    // Use keys + getAll via any-cast to avoid TS DOM lib differences
    const keys = Array.from((fd as any).keys()) as string[];
    for (let i = 0; i < keys.length; ++i) {
      const k = keys[i];
      const vals: any[] = (fd as any).getAll(k);
      for (let vi = 0; vi < vals.length; ++vi) {
        const v = vals[vi];
        if (!Object.prototype.hasOwnProperty.call(data, k)) (data as any)[k] = v;
        else if (!Array.isArray((data as any)[k])) (data as any)[k] = [(data as any)[k], v];
        else (data as any)[k].push(v);
      }
    }
    return data;
  }

  private _attachAutoValidation() {
    this._autosaveHandler = debounce(() => { try { if (this.opts.autoSaveKey) this._saveDraft(); } catch (e) { } }, 400);
    this._conditionalHandler = debounce(() => { try { this._applyConditionalFields(); } catch (e) { } }, 140);
    this.form.addEventListener('input', this._autosaveHandler, { passive: true } as any);
    this.form.addEventListener('change', this._autosaveHandler, { passive: true } as any);
    this.form.addEventListener('input', this._conditionalHandler, { passive: true } as any);
    this.form.addEventListener('change', this._conditionalHandler, { passive: true } as any);
  }

  private _onDomSubmit(e: Event) {
    try {
      if (this.opts.validateOn === 'submit') {
        const ok = this._validateAll();
        if (!ok) { e.preventDefault(); this.emitter.emit('validationFailed', this); return; }
      }
      if (this.opts.ajax) {
        e.preventDefault();
        void this.submit();
      }
    } catch (err) {
      if (this.debug && console && console.error) console.error(err);
    }
  }

  private _validateAll(): boolean {
    const els = this.form.querySelectorAll('[data-validate]');
    let ok = true;
    for (let i = 0; i < els.length; ++i) {
      const el = els[i] as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
      const rules = (el.getAttribute('data-validate') || '').split('|').map(s => s.trim()).filter(Boolean);
      const value = (el as HTMLInputElement).type === 'file' ? ((el as HTMLInputElement).files && (el as HTMLInputElement).files![0]) : (el as any).value;
      for (let j = 0; j < rules.length; ++j) {
        const r = rules[j];
        const idx = r.indexOf(':');
        const name = idx > -1 ? r.slice(0, idx) : r;
        const param = idx > -1 ? r.slice(idx + 1) : null;
        const result = this.validators.run(name, value, param, el);
        if (result !== true) {
          ok = false;
          this._renderFieldError(el, result);
          break;
        } else {
          this._clearFieldError(el);
        }
      }
    }
    return ok;
  }

  private _renderFieldError(el: Element, msg: any) {
    this._clearFieldError(el);
    const e = document.createElement('div');
    e.className = 'yf-error';
    (e.style as any).color = '#b00020';
    (e.style as any).fontSize = '0.9rem';
    e.textContent = typeof msg === 'string' ? msg : String(msg || 'Invalid');
    el.insertAdjacentElement('afterend', e);
  }

  private _clearFieldError(el: Element) {
    const next = el.nextElementSibling;
    if (next && next.classList && next.classList.contains('yf-error')) next.remove();
  }

  async submit(): Promise<any> {
    try {
      for (let i = 0; i < this.plugins.length; ++i) {
        const p = this.plugins[i];
        if (p && typeof p.beforeSubmit === 'function') {
          const r = await p.beforeSubmit(this);
          if (r && r.continue === false) return r;
        }
      }

      let body: BodyInit | string | null = null;
      const headers: Record<string, string> = {};
      if (this.opts.formDataMode === 'formdata') {
        body = new FormData(this.form);
        if (this.opts.extraFields) {
          for (const k in this.opts.extraFields) {
            if (!Object.prototype.hasOwnProperty.call(this.opts.extraFields, k)) continue;
            const v = this.opts.extraFields[k];
            (body as FormData).append(k, typeof v === 'function' ? v() : v);
          }
        }
      } else {
        body = JSON.stringify(this.getData());
        headers['Content-Type'] = 'application/json';
      }

      this.emitter.emit('submitStart', this);
      yantra.showLoader && yantra.showLoader();

      const optsReq: RequestInit = { method: (this.opts.method || 'POST'), body, headers: Object.assign({}, this.opts.headers || {}, headers) as any };
      const res = await fetchWithRetries(this.opts.url || this.form.action, optsReq, this.opts.fetchRetries || 0, this.opts.fetchTimeout || 7000);

      this.emitter.emit('submitSuccess', res, this);
      if (this.opts.autoReset) this.form.reset();
      return res;
    } catch (err) {
      const mapped = (typeof this.opts.serverErrorMapper === 'function') ? this.opts.serverErrorMapper(err) : null;
      if (mapped) this.applyServerErrors(mapped, err);
      this.emitter.emit('submitError', err, this);
      throw err;
    } finally {
      yantra.hideLoader && yantra.hideLoader();
      this.emitter.emit('submitEnd', this);
    }
  }

  applyServerErrors(mapped: { fieldErrors?: Record<string, string>, globalErrors?: string[] } | null, raw?: any) {
    if (!mapped) return false;
    const { fieldErrors = {}, globalErrors = [] } = mapped;
    const leftover = Array.isArray(globalErrors) ? globalErrors.slice() : [];
    let any = false;
    for (const k in fieldErrors) {
      if (!Object.prototype.hasOwnProperty.call(fieldErrors, k)) continue;
      const msg = fieldErrors[k];
      const el = this.form.querySelector(`[name="${k}"]`) || this.form.querySelector(`#${k}`);
      if (el) { this._renderFieldError(el, msg); any = true; }
      else leftover.push(`${k}: ${msg}`);
    }
    if (leftover.length) {
      this.serverGlobalErrors = leftover;
      this.emitter.emit('serverGlobalErrors', leftover, this);
    } else this.serverGlobalErrors = [];
    this.emitter.emit('serverValidationFailed', { fieldErrors, globalErrors: leftover }, this);
    return any;
  }

  private _initRepeatables() {
    // intentionally minimal; extend per-app needs
  }

  private _applyConditionalFields() {
    const nodes = this.form.querySelectorAll('[data-show-if]');
    for (let i = 0; i < nodes.length; ++i) {
      const n = nodes[i] as HTMLElement;
      const expr = n.getAttribute('data-show-if');
      try {
        const visible = (new Function('form', 'with(form){ return !!(' + expr + ')}'))(this.form);
        n.style.display = visible ? '' : 'none';
      } catch (e) {
        n.style.display = 'none';
      }
    }
  }

  enableAutoSave(key: string, opts?: { interval?: number, restore?: boolean }) {
    opts = opts || {};
    this.opts.autoSaveKey = key;
    const interval = opts.interval || 600;
    this._autoSaveIntervalId = window.setInterval(() => {
      try { this._saveDraft(); } catch (e) { }
    }, interval);
    if (opts.restore) {
      const saved = (yantra.store && typeof yantra.store.get === 'function') ? yantra.store.get(key) : null;
      if (saved && typeof saved === 'object') {
        for (const k in saved) {
          try {
            const el = this.form.querySelector(`[name="${k}"]`) as HTMLInputElement | null;
            if (el && el.type !== 'file') el.value = saved[k];
          } catch (e) { }
        }
      }
    }
    return this;
  }
  private _autoSaveIntervalId: number | null = null;

  private _saveDraft() {
    if (!this.opts.autoSaveKey) return;
    const data = this.getData();
    for (const k in data) {
      const v = data[k];
      if (v instanceof File || v instanceof Blob) delete data[k];
    }
    if (yantra.store && typeof yantra.store.set === 'function') yantra.store.set(this.opts.autoSaveKey!, data);
    this.emitter.emit('autoSaved', this.opts.autoSaveKey, this);
  }

  clearDraft() {
    if (!this.opts.autoSaveKey) return;
    if (yantra.store && typeof yantra.store.remove === 'function') yantra.store.remove(this.opts.autoSaveKey!);
    this.emitter.emit('autoDraftCleared', this.opts.autoSaveKey, this);
  }

  destroy() {
    if (this._destroyed) return;
    this._destroyed = true;
    try { this.form.removeEventListener('submit', this._boundSubmit); } catch (e) { }
    try { this.form.removeEventListener('input', this._autosaveHandler); this.form.removeEventListener('change', this._autosaveHandler); } catch (e) { }
    try { this.form.removeEventListener('input', this._conditionalHandler); this.form.removeEventListener('change', this._conditionalHandler); } catch (e) { }
    for (const p of this.plugins) { if (p && isFunction(p.destroy)) { try { p.destroy(this); } catch (e) { console.error(e); } } }
    this.emitter = new Emitter();
    try { delete (this.form as any).__yantra_form__; } catch (e) { }
    if (this._autoSaveIntervalId) { window.clearInterval(this._autoSaveIntervalId); this._autoSaveIntervalId = null; }
  }
}

/* ----------------------
   Plugins
   ---------------------- */

export const Plugins = {
  chunkUploader: (options: any = {}) => {
    return (engine: YantraForm) => {
      const opt = Object.assign({ selector: 'input[type=file][data-chunk]', registerFieldPrefix: null, url: null }, options);
      const progressEmit = throttleByTime((pct: number, fileEl: HTMLInputElement) => {
        try { engine.emitter.emit('uploadProgress', { file: fileEl, percent: pct }, engine); } catch (e) { }
      }, 125);

      return {
        beforeSubmit: async (frmEngine: YantraForm) => {
          const files = Array.from(frmEngine.form.querySelectorAll(opt.selector)) as HTMLInputElement[];
          if (files.length === 0) return { continue: true };
          if (!(yantra.uploadFileInChunks && typeof yantra.uploadFileInChunks === 'function')) {
            throw new Error('No global chunk uploader available (yantra.uploadFileInChunks)');
          }
          const promises = files.map(fi => {
            const file = fi.files && fi.files[0];
            if (!file) return Promise.resolve(null);
            const registerKey = opt.registerFieldPrefix ? (opt.registerFieldPrefix + '_' + (fi.name || fi.id || 'file')) : (fi.name || fi.id || 'file');
            const upOpts = {
              url: opt.url || undefined,
              registerFieldId: registerKey,
              onProgress: (pct: number) => progressEmit(pct, fi)
            };
            const upFn = yantra.uploadFileInChunks!;
            return upFn(file, upOpts).then(res => {
              try {
                if (!frmEngine.opts.extraFields) frmEngine.opts.extraFields = {};
                frmEngine.opts.extraFields[registerKey + '_file_id'] = () => (res && (res as any).fileId) || null;
              } catch (e) { }
              return res;
            });
          });
          const results = await Promise.all(promises);
          return { continue: true, uploads: results };
        }
      };
    };
  }
};

/* ----------------------
   attach globals & adapter
   ---------------------- */

yantra.createForm = function (selectorOrEl: string | HTMLFormElement, opts?: Partial<YantraFormOptions>) {
  try { return new YantraForm(selectorOrEl as any, opts); } catch (e) { console.warn('YantraForm not available', e); return null; }
};

// stub uploadFileInChunks (replace with production implementation)
if (!yantra.uploadFileInChunks) {
  yantra.uploadFileInChunks = function (file: File, opts?: { url?: string, onProgress?: (pct:number)=>void, registerFieldId?: string }) {
    return new Promise<UploadResult>((resolve) => {
      const total = file.size || 1000000;
      let sent = 0;
      const step = Math.max(200000, Math.floor(total / 6));
      const id = 'fakefile_' + Date.now();
      function tick() {
        sent = Math.min(total, sent + step);
        const pct = Math.round((sent / total) * 100);
        if (opts && typeof opts.onProgress === 'function') opts.onProgress(pct);
        if (sent < total) setTimeout(tick, 160); else setTimeout(() => resolve({ fileId: id }), 260);
      }
      setTimeout(tick, 80);
    });
  };
}

/* expose to window (no duplicate ambient declare to avoid TS2687 conflicts) */
if (typeof window !== 'undefined') {
  try {
    (window as any).yantra = Object.assign((window as any).yantra || {}, yantra) as YantraAPI;
    (window as any).YantraForm = YantraForm;
    (window as any).YantraForm!.plugins = (window as any).YantraForm!.plugins || {};
    (window as any).YantraForm!.plugins.chunkUploader = Plugins.chunkUploader;
  } catch (e) { /* ignore attach errors in locked environments */ }
}

export default yantra as YantraAPI;
