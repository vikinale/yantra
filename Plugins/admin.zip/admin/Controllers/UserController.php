<?php
namespace Plugins\admin\Controllers;

use Core\Controllers\BaseController;
use Couchbase\User;
use Exception;
use JetBrains\PhpStorm\NoReturn;
use Plugins\admin\Services\UserService;
use Plugins\admin\Services\UserSessionService;
use System\Request;
use System\Response;

class UserController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }

    #[NoReturn] public function index(Request $request, Response $response): void
    {
        $response->page->slug = $request->getPath();
        $response->page->title = "Home Page";
        try {
            $response->add('pagetop','preloader');
            $response->add('pagetop','notifications');
            $response->add('topnav','topnav');
            $response->add('sidebar','sidebar');
            $response->add('content','users/list');
        }
        catch (Exception $e) {
            echo $e->getMessage();
        }
        $response->render();
    }

    #[NoReturn] public function create(Request $request, Response $response): void
    {
        if($request->isGet()){
            $response->page->slug = $request->getPath();
            $response->page->title = "Home Page";
            $user_service = new UserService();
            try {
                $response->add('pagetop','preloader');
                $response->add('pagetop','notifications');
                $response->add('topnav','topnav');
                $response->add('sidebar','sidebar');
                $user_roles = $user_service->getRoles();
                $response->add('content','users/create',['roles'=>$user_roles]);
            }
            catch (Exception $e) {
                echo $e->getMessage();
            }
            $response->render();
        }
        elseif($request->isPost())
        {
            $username = $request->input('username');
            $email = $request->input('email');
            $password = $request->input('password');
            $role = $request->input('role');

            $response->json(array('status'=>false,'errors'=>array(
                'username'=>"$username username is not available."
            )));
        }
        else{
            $response->not_found();
        }
    }

}