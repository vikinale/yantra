<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Footer Area -->
            <footer class="footer-area d-sm-flex justify-content-center align-items-center justify-content-between">
                <!-- Copywrite Text -->
                <div class="copywrite-text">
                    <p class="font-13">
                        Developed by &copy; <a href="#">WPoest</a>
                    </p>
                </div>
                <div class="fotter-icon text-center">
                    <p class="mb-0 font-13">2024 &copy; Walnut</p>
                </div>
            </footer>
        </div>
    </div>
</div>