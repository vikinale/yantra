<footer>
    <p>&copy; 2024 Yantra</p>
</footer>