<?php
require_once 'functions.php';
?>
<!DOCTYPE html>
<html>
<head>
    <?php get_header(); ?>
</head>
<body>
<?php get_content(); ?>
<?php get_footer(); ?>
</body>
</html>