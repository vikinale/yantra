<?php
namespace Plugins\admin\UserManager;

class UserManager {

    public function __construct()  {
    }
    public static function createUser(){

    }
    public static function deleteUser(){

    }
    public static function updateUser(){

    }
    public static function addUserRole(){

    }
    public static function removeUserRole(){

    }
    public static function activateUser(){

    }
    public static function deactivateUser(){

    }
    public static function startUserSession(){

    }
    public static function deleteUserSession(){

    }
}